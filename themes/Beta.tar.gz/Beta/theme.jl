; Beta/theme.jl



(let*
  (
    (font (get-font "-*-lucida-medium-r-normal-*-*-100-*-*-p-*-iso8859-1"))
    (font-colors (list "white" "#ff9b05"))
    
	(title-images (list (make-image "title-bar-inactive.png")
                            (make-image "title-bar-active.png")))

        (inset-images (list (set-image-border
	                    (make-image "title-inset-inactive.png") 10 10 0 0)
	                    (set-image-border
			    (make-image "title-inset-active.png")10 10 0 0)))

     	(iconify-images (list (make-image "iconify-normal.png")
			      nil nil
                              (make-image "iconify-clicked.png")))

     	(maximize-images (list (make-image "maximize-normal.png")
                               nil nil
  	 		       (make-image "maximize-clicked.png")))

     	(close-images (list (make-image "close-normal.png")
			    nil nil
                            (make-image "close-clicked.png")))

         (menu-images (list (make-image "menu-normal.png")
	                     nil nil
			     (make-image "menu-clicked.png")))

     	(border-top (make-image "border_top.png"))
     	(border-bottom (make-image "border_bottom.png"))
     	(border-right (make-image "border_right.png"))
     	(border-left (make-image "border_left.png"))

     	(corner-tl (make-image "corner_top_left.png"))
     	(corner-tr (make-image "corner_top_right.png"))
     	(corner-bl (make-image "corner_bottom_left.png"))
     	(corner-br (make-image "corner_bottom_right.png"))

     	(frame `(
		((background . ,title-images)
		 (top-edge . -16)
		 (left-edge . 0)
		 (class . title))

		((background . ,title-images)
		 (foreground . ,font-colors)
		 (top-edge . -16)
		 (left-edge . 0)
		 (right-edge . 0)
		 (class . title))
		 
		 ((background . ,inset-images)
		  (foreground . ,font-colors)
		  (font . ,font)
		  (text . ,window-name)
		  (x-justify . center)
                  (y-justify . center)
		  (top-edge . -14)		  
		  (left-edge . 16)
		  (right-edge . 40)
		  (class . title))

		((background . ,iconify-images)
      		 (top-edge . -13)
		 (right-edge . 26) 
		 (class . iconify-button))

                ((background . ,menu-images)
		 (top-edge . -13)
		 (left-edge . 1)
		 (class . menu-button))

     		((background . ,maximize-images)
      		 (top-edge . -13)
      		 (right-edge . 13)
      		 (class . maximize-button))

    		((background . ,close-images)
      		 (top-edge . -13)
      		 (right-edge . 1)
      		 (class . close-button))

     		((background . ,border-left)
      		 (top-edge . -16)
      		 (bottom-edge . 0)
      		 (left-edge . -2) 
      		 (class . left-border))

     		((background . ,border-right)
      		 (top-edge . -16)
      		 (bottom-edge . 0)
      		 (right-edge . -2)
      		 (class . right-border))

	     	((background . ,border-top)
      		 (top-edge . -18)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . top-border))

     		((background . ,border-bottom)
      		 (bottom-edge . -2)
      		 (right-edge . 0)  
      		 (left-edge . 0)   
      		 (class . bottom-border))

     		((background . ,corner-tl)
      		 (top-edge . -18)
      		 (left-edge . -2)
      		 (class . top-left-corner))

     		((background . ,corner-tr)
      		 (top-edge . -18)
      		 (right-edge . -2)
      		 (class . top-right-corner))

     		((background . ,corner-bl)
      		 (bottom-edge . -2)
      		 (left-edge . -2)  
      		 (class . bottom-left-corner))

     		((background . ,corner-br)
      		 (bottom-edge . -2)
      		 (right-edge . -2) 
      		 (class . bottom-right-corner))
	))

	(shaped-frame `(
     		((background . ,title-images)
      		 (top-edge . -16)
      		 (left-edge . 0) 
      		 (class . iconify-button))
      
     		((background . ,title-images)
      		 (top-edge . -16)
      		 (left-edge . 0)
      		 (right-edge . 0)
      		 (class . title))
		 
		 ((background . ,inset-images)
		  (foreground . ,font-colors)
		  (font . ,font)
		  (text . ,window-name)
                  (x-justify . center)
		  (y-justify . center)
		  (top-edge . -14)
                  (left-edge . 16)
                  (right-edge . 40)
		  (class . title))

     		((background . ,iconify-images)
      		 (top-edge . -13)
      		 (right-edge . 26) 
      		 (class . iconify-button))

                ((background . ,menu-images)
		 (top-edge . -13)
		 (left-edge . 1)
		 (class . menu-button))

     		((background . ,maximize-images)
      		 (top-edge . -13)
      		 (right-edge . 13)
      		 (class . maximize-button))

     		((background . ,close-images)
      		 (top-edge . -13)
      		 (right-edge . 1)
      		 (class . close-button))

     		((background . ,border-left)
      		 (top-edge . -16)
      		 ;;(bottom-edge . 0)
      		 (left-edge . -2)   
      		 (class . left-border))

     		((background . ,border-right)
      		 (top-edge . -16)
      		 ;;(bottom-edge . 0)
      		 (right-edge . -2)  
      		 (class . right-border))

     		((background . ,border-top)
      		 (top-edge . -18)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . top-border))

     		((background . ,border-bottom)
      		 (top-edge . 0)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . bottom-border))

         	((background . ,corner-tl)
      		 (top-edge . -18)
      		 (left-edge . -2)
      		 (class . top-left-corner))

     		((background . ,corner-tr)
      		 (top-edge . -18)
      		 (right-edge . -2)
      		 (class . top-right-corner))

     		((background . ,corner-bl)
      		 (top-edge . 0)
      		 (left-edge . -2)
      		 (class . bottom-left-corner))

     		((background . ,corner-br)
      		 (top-edge . 0)
      		 (right-edge . -2)
      		 (class . bottom-right-corner))
	))

	(transient-frame `(
		((background . ,title-images)
		 (top-edge . -16)
		 (left-edge . 0)
		 (class . iconify-button))

		((background . ,title-images)
		 (top-edge . -16)
		 (left-edge . 0)
		 (right-edge . 0)
		 (class . title))
		 
		 ((background . ,inset-images)
		  (foreground . ,font-colors)
		  (font . ,font)
		  (text . ,window-name)
                  (x-justify . center)
		  (y-justify . center)
		  (top-edge . -14)
		  (left-edge . 16)
                  (right-edge . 26)
		  (class . title))

		((background . ,iconify-images)
      		 (top-edge . -13)
		 (right-edge . 13) 
		 (class . iconify-button))

                ((background . ,menu-images)
		 (top-edge . -13)
		 (left-edge . 1)
		 (class . menu-button))

    		((background . ,close-images)
      		 (top-edge . -13)
      		 (right-edge . 1)
      		 (class . close-button))

     		((background . ,border-left)
      		 (top-edge . -16)
      		 (bottom-edge . 0)
      		 (left-edge . -2) 
      		 (class . left-border))

     		((background . ,border-right)
      		 (top-edge . -16)
      		 (bottom-edge . 0)
      		 (right-edge . -2)
      		 (class . right-border))

	     	((background . ,border-top)
      		 (top-edge . -18)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . top-border))

     		((background . ,border-bottom)
      		 (bottom-edge . -2)
      		 (right-edge . 0)  
      		 (left-edge . 0)   
      		 (class . bottom-border))

     		((background . ,corner-tl)
      		 (top-edge . -18)
      		 (left-edge . -2)
      		 (class . top-left-corner))

     		((background . ,corner-tr)
      		 (top-edge . -18)
      		 (right-edge . -2)
      		 (class . top-right-corner))

     		((background . ,corner-bl)
      		 (bottom-edge . -2)
      		 (left-edge . -2)  
      		 (class . bottom-left-corner))

     		((background . ,corner-br)
      		 (bottom-edge . -2)
      		 (right-edge . -2) 
      		 (class . bottom-right-corner))
	))
	
	(shaped-transient-frame `(
     		((background . ,title-images)
      		 (top-edge . -16)
      		 (left-edge . 0) 
      		 (class . iconify-button))
      
     		((background . ,title-images)
      		 (top-edge . -16)
      		 (left-edge . 0)
      		 (right-edge . 0)
      		 (class . title))
		 
		 ((background . ,inset-images)
		  (foreground . ,font-colors)
		  (font . ,font)
		  (text . ,window-name)
                  (x-justify . center)
		  (y-justify . center)
		  (top-edge . -14)
		  (left-edge . 16)
                  (right-edge . 26)
		  (class . title))				    

     		((background . ,iconify-images)
      		 (top-edge . -13)
      		 (right-edge . 13) 
      		 (class . iconify-button))
		 
		((background . ,menu-images)
		 (top-edge . -13)
		 (left-edge . 1)
		 (class . menu-button))

     		((background . ,close-images)
      		 (top-edge . -13)
      		 (right-edge . 1)
      		 (class . close-button))

     		((background . ,border-left)
      		 (top-edge . -16)
      		 ;;(bottom-edge . 0)
      		 (left-edge . -2)   
      		 (class . left-border))

     		((background . ,border-right)
      		 (top-edge . -16)
      		 ;;(bottom-edge . 0)
      		 (right-edge . -2)  
      		 (class . right-border))

     		((background . ,border-top)
      		 (top-edge . -18)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . top-border))

     		((background . ,border-bottom)
      		 (top-edge . 0)
      		 (right-edge . 0)
      		 (left-edge . 0) 
      		 (class . bottom-border))

         	((background . ,corner-tl)
      		 (top-edge . -18)
      		 (left-edge . -2)
      		 (class . top-left-corner))

     		((background . ,corner-tr)
      		 (top-edge . -18)
      		 (right-edge . -2)
      		 (class . top-right-corner))

     		((background . ,corner-bl)
      		 (top-edge . 0)
      		 (left-edge . -2)
      		 (class . bottom-left-corner))

     		((background . ,corner-br)
      		 (top-edge . 0)
      		 (right-edge . -2)
      		 (class . bottom-right-corner))
	))
	
  )
  (add-frame-style 'Beta
    	(lambda (w type)   
          (case type
	     ((default) frame)
	     ((transient) transient-frame)
	     ((shaped) shaped-frame)
	     ((shaped-transient) shaped-transient-frame)))))
