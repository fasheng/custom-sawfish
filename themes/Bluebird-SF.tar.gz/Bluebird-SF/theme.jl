;; Name    : Bluebird-SF. Based on XFCE Bluebird theme.
;; Author  : Sergey Briskin <sergey.briskin@gmail.com>
;; License : GPL-2

(let*
  (
    (iclose  (list (make-image "close.png")       nil nil nil))
    (imax    (list (make-image "max.png")         nil nil nil))
    (imin    (list (make-image "min.png")         nil nil nil))
    (ititle  (list (make-image "title.png")       nil nil nil))
    (imenu   (list (make-image "menu.png")        nil nil nil))
    (ibl     (list (make-image "bl.png")          nil nil nil))
    (ibr     (list (make-image "br.png")          nil nil nil))
    (iright  (list (make-image "right.png")       nil nil nil))
    (ileft   (list (make-image "left.png")        nil nil nil))
    (ibottom (list (make-image "bottom.png")      nil nil nil))
    (ibtbg   (list (make-image "btbg.png")        nil nil nil))
    (imenubg (list (make-image "menubg.png")      nil nil nil))

    (default-frame
     `(
        ((background . ,ibtbg)  (right-edge . -2) (width . 81)        (height . 19) (top-edge . -19) (class . title))
        ((background . ,imenubg)(left-edge . -2)  (width . 21)        (height . 19) (top-edge . -19) (class . title))

        ((background . ,iclose)  (right-edge . 1)                   (width . 15)               (top-edge . -17)                    (class . close-button))
        ((background . ,imax)    (right-edge . 20)                  (width . 15)               (top-edge . -17)                    (class . maximize-button))
        ((background . ,imin)    (right-edge . 38)                  (width . 15)               (top-edge . -17)                    (class . iconify-button))
        ((background . ,imenu)                     (left-edge . 0)  (width . 15)               (top-edge . -17)                    (class . menu-button))
        ((background . ,iright)  (right-edge . -2)                  (width . 2)                (top-edge . 0)   (bottom-edge . 0)  (class . right-border))
        ((background . ,ileft)                     (left-edge . -2) (width . 2)                (top-edge . 0)   (bottom-edge . 0)  (class . left-border))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0)               (height . 2)                   (bottom-edge . -2) (class . bottom-border))
        ((background . ,ibl)                       (left-edge . -2) (width . 2)  (height . 2)                   (bottom-edge . -2) (class . bottom-left-corner))
        ((background . ,ibr)     (right-edge . -2)                  (width . 2)  (height . 2)                   (bottom-edge . -2) (class . bottom-right-corner))

        ((background . ,ititle)  (right-edge . 70) (left-edge . 16)              (height . 19) (top-edge . -19) 
         (foreground . ("gray" "white"))  (text . ,window-name) (x-justify . center) (y-justify . center) (class . title))
      )
    )

    (shaded-frame
     `(
        ((background . ,ibtbg)  (right-edge . -2) (width . 81)        (height . 19) (top-edge . -19) (class . title))
        ((background . ,imenubg)(left-edge . -2)  (width . 21)        (height . 19) (top-edge . -19) (class . title))

        ((background . ,iclose)  (right-edge . 1)                   (width . 15)               (top-edge . -17)                    (class . close-button))
        ((background . ,imax)    (right-edge . 20)                  (width . 15)               (top-edge . -17)                    (class . maximize-button))
        ((background . ,imin)    (right-edge . 38)                  (width . 15)               (top-edge . -17)                    (class . iconify-button))
        ((background . ,imenu)                     (left-edge . 0)  (width . 15)               (top-edge . -17)                    (class . menu-button))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0)  (height . 2)               (top-edge . 0) (class . bottom-border))
        ((background . ,ibl)                       (left-edge . -2) (width . 2)  (height . 2)  (top-edge . 0) (class . bottom-left-corner))
        ((background . ,ibr)     (right-edge . -2)                  (width . 2)  (height . 2)  (top-edge . 0) (class . bottom-right-corner))

        ((background . ,ititle)  (right-edge . 70) (left-edge . 16)              (height . 19) (top-edge . -19) 
         (foreground . ("gray" "white"))  (text . ,window-name) (x-justify . center) (y-justify . center) (class . title))

      )
    )

    (transident-frame
     `(
        ((background . ,ibtbg)  (right-edge . -2) (width . 81)        (height . 19) (top-edge . -19) (class . title))
        ((background . ,imenubg)(left-edge . -2)  (width . 21)        (height . 19) (top-edge . -19) (class . title))

        ((background . ,iclose)  (right-edge . 1)                   (width . 15)               (top-edge . -17)                    (class . close-button))
        ((background . ,imin)    (right-edge . 20)                  (width . 15)               (top-edge . -17)                    (class . iconify-button))
        ((background . ,imenu)                     (left-edge . 0)  (width . 15)               (top-edge . -17)                    (class . menu-button))
        ((background . ,iright)  (right-edge . -2)                  (width . 2)                (top-edge . 0)   (bottom-edge . 0)  (class . right-border))
        ((background . ,ileft)                     (left-edge . -2) (width . 2)                (top-edge . 0)   (bottom-edge . 0)  (class . left-border))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0)               (height . 2)                   (bottom-edge . -2) (class . bottom-border))
        ((background . ,ibl)                       (left-edge . -2) (width . 2)  (height . 2)                   (bottom-edge . -2) (class . bottom-left-corner))
        ((background . ,ibr)     (right-edge . -2)                  (width . 2)  (height . 2)                   (bottom-edge . -2) (class . bottom-right-corner))

        ((background . ,ititle)  (right-edge . 70) (left-edge . 17)              (height . 19) (top-edge . -19) 
         (foreground . ("gray" "white"))  (text . ,window-name) (x-justify . center) (y-justify . center) (class . title))

      )
    )

    (shaded-transident-frame
     `(
        ((background . ,ibtbg)  (right-edge . -2) (width . 81)        (height . 19) (top-edge . -19) (class . title))
        ((background . ,imenubg)(left-edge . -2)  (width . 21)        (height . 19) (top-edge . -19) (class . title))

        ((background . ,iclose)  (right-edge . 1)                   (width . 15)               (top-edge . -19)                    (class . close-button))
        ((background . ,imin)    (right-edge . 20)                  (width . 15)               (top-edge . -19)                    (class . iconify-button))
        ((background . ,imenu)                     (left-edge . 0)  (width . 15)               (top-edge . -15)                    (class . menu-button))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0)  (height . 2)               (top-edge . 0) (class . bottom-border))
        ((background . ,ibl)                       (left-edge . -2) (width . 2)  (height . 2)  (top-edge . 0) (class . bottom-left-corner))
        ((background . ,ibr)     (right-edge . -2)                  (width . 2)  (height . 2)  (top-edge . 0) (class . bottom-right-corner))

        ((background . ,ititle)  (right-edge . 70) (left-edge . 17)              (height . 19) (top-edge . -19) 
         (foreground . ("gray" "white"))  (text . ,window-name) (x-justify . center) (y-justify . center) (class . title))

      )
    )
  )

  (add-frame-style 'Bluebird-SF 
    (lambda (w type) 
      (case type 
        ((default) default-frame)
        ((transient) transident-frame)
        ((shaped) shaded-frame)
        ((shaped-transient) shaded-transident-frame)
      )
    )
  )
)
