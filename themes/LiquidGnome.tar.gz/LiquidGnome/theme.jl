;; theme file, written Sun Apr 15 19:35:33 2001
;; created by sawfish-themer -- DO NOT EDIT!

(require 'make-theme)

(let
    ((patterns-alist
      '(("maximize"
         (inactive
          "maximize-inactive.png")
         (focused
          "maximize.png")
         (highlighted
          "maximize-highlighted.png")
         (clicked
          "maximize.png"))
        ("minimize"
         (inactive
          "minimize-inactive.png")
         (focused
          "minimize.png")
         (highlighted
          "minimize-highlighted.png")
         (clicked
          "minimize.png"))
        ("close"
         (inactive
          "close-inactive.png")
         (focused
          "close.png")
         (highlighted
          "close-highlighted.png")
         (clicked
          "close.png"))
        ("titlebar"
         (inactive
          "titlebar-inactive.png")
         (focused
          "titlebar.png")
         (highlighted
          "titlebar-highlighted.png")
         (clicked
          "titlebar.png"))
        ("grabby"
         (inactive
          "grabby-inactive.png")
         (focused
          "grabby.png")
         (highlighted
          "grabby-highlighted.png")
         (clicked
          "grabby.png"))
        ("top-border"
         (inactive
          "top-border-inactive.png")
         (focused
          "top-border.png")
         (highlighted
          "top-border-highlighted.png")
         (clicked
          "top-border.png"))
        ("topright"
         (inactive
          "topright-inactive.png")
         (focused
          "topright.png")
         (highlighted
          "topright-highlighted.png")
         (clicked
          "topright.png"))
        ("topleft"
         (inactive
          "topleft-inactive.png")
         (focused
          "topleft.png")
         (highlighted
          "topleft-highlighted.png")
         (clicked
          "topleft.png"))
        ("left"
         (inactive
          "left-inactive.png")
         (focused
          "left.png")
         (highlighted
          "left-highlighted.png")
         (clicked
          "left.png"))
        ("right"
         (inactive
          "right-inactive.png")
         (focused
          "right.png")
         (highlighted
          "right-highlighted.png")
         (clicked
          "right.png"))
        ("bottom"
         (inactive
          "bottom-inactive.png")
         (focused
          "bottom.png")
         (highlighted
          "bottom-highlighted.png")
         (clicked
          "bottom.png"))
        ("bottom-shade"
         (inactive
          "bottom-shade-inactive.png")
         (focused
          "bottom-shade.png")
         (highlighted
          "bottom-shade-highlighted.png")
         (clicked
          "bottom-shade.png"))
        ("bottom-left"
         (inactive
          "bottom-left-inactive.png")
         (focused
          "bottom-left.png")
         (highlighted
          "bottom-left-highlighted.png")
         (clicked
          "bottom-left.png"))
        ("bottom-right"
         (inactive
          "bottom-right-inactive.png")
         (focused
          "bottom-right.png")
         (highlighted
          "bottom-right-highlighted.png")
         (clicked
          "bottom-right.png"))))

     (frames-alist
      '(("normal"
         ((height . 20)
          (top-edge . -20)
          (right-edge . 38)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 22)
          (height . 20)
          (background . "minimize")
          (top-edge . -20)
          (class . iconify-button))
         ((right-edge . 6)
          (top-edge . -20)
          (height . 20)
          (background . "close")
          (class . close-button))
         ((font . "-adobe-helvetica-medium-r-normal-*-*-80-*-*-p-*-iso8859-1")
          (left-edge . 21)
          (right-edge . 53)
          (top-edge . -20)
          (background . "titlebar")
          (class . title)
          (text . window-name)
          (x-justify . 10)
          (y-justify . 5)
          (foreground . "#e8b9e8b9e8b9"))
         ((left-edge . 5)
          (height . 20)
          (top-edge . -20)
          (background . "grabby")
          (class . menu-button))
         ((right-edge . 0)
          (background . "topright")
          (top-edge . -20)
          (class . title))
         ((left-edge . -1)
          (top-edge . -20)
          (background . "topleft")
          (class . title))
         ((right-edge . 15)
          (left-edge . 14)
          (bottom-edge . -5)
          (background . "bottom")
          (class . bottom-border))
         ((left-edge . 0)
          (bottom-edge . -5)
          (background . "bottom-left")
          (class . bottom-left-corner))
         ((bottom-edge . -5)
          (right-edge . 0)
          (background . "bottom-right")
          (class . bottom-right-corner)))
        ("shaped"
         ((right-edge . 38)
          (height . 20)
          (top-edge . -20)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 22)
          (height . 20)
          (top-edge . -20)
          (background . "minimize")
          (class . iconify-button))
         ((right-edge . 6)
          (height . 20)
          (top-edge . -20)
          (background . "close")
          (class . close-button))
         ((right-edge . 53)
          (left-edge . 22)
          (font . "-adobe-helvetica-medium-r-normal-*-*-80-*-*-p-*-iso8859-1")
          (y-justify . 5)
          (top-edge . -20)
          (background . "titlebar")
          (class . title)
          (text . window-name)
          (x-justify . 10)
          (foreground . "#e4d8e4d8e4d8"))
         ((top-edge . -20)
          (left-edge . 6)
          (height . 20)
          (background . "grabby")
          (class . menu-button))
         ((class . title)
          (right-edge . 0)
          (top-edge . -20)
          (background . "topright"))
         ((class . title)
          (left-edge . 0)
          (top-edge . -20)
          (background . "topleft"))
         ((top-edge . 0)
          (right-edge . 0)
          (left-edge . 0)
          (background . "bottom-shade")
          (class . bottom-border)))
        ("transient"
         ((right-edge . 38)
          (height . 20)
          (top-edge . -20)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 22)
          (height . 20)
          (top-edge . -20)
          (background . "minimize")
          (class . iconify-button))
         ((right-edge . 6)
          (height . 20)
          (top-edge . -20)
          (background . "close")
          (class . close-button))
         ((left-edge . 22)
          (right-edge . 53)
          (font . "-adobe-helvetica-medium-r-normal-*-*-80-*-*-p-*-iso8859-1")
          (top-edge . -20)
          (background . "titlebar")
          (class . title)
          (text . window-name)
          (x-justify . 10)
          (y-justify . 5)
          (foreground . "#e6c8e6c8e6c8"))
         ((height . 20)
          (top-edge . -20)
          (background . "grabby")
          (left-edge . 6)
          (class . menu-button))
         ((class . title)
          (right-edge . 0)
          (top-edge . -20)
          (background . "topright"))
         ((class . title)
          (left-edge . 0)
          (top-edge . -20)
          (background . "topleft"))
         ((left-edge . 10)
          (right-edge . 10)
          (class . bottom-border)
          (bottom-edge . -5)
          (background . "bottom"))
         ((bottom-edge . -5)
          (left-edge . 0)
          (background . "bottom-left")
          (class . bottom-left-corner))
         ((bottom-edge . -5)
          (right-edge . 0)
          (background . "bottom-right")
          (class . bottom-right-corner)))
        ("shaped-transient"
         ((right-edge . 38)
          (height . 20)
          (top-edge . -20)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 22)
          (height . 20)
          (top-edge . -20)
          (background . "minimize")
          (class . iconify-button))
         ((right-edge . 6)
          (height . 20)
          (top-edge . -20)
          (background . "close")
          (class . close-button))
         ((right-edge . 53)
          (left-edge . 22)
          (font . "-adobe-helvetica-medium-r-normal-*-*-80-*-*-p-*-iso8859-1")
          (background . "titlebar")
          (top-edge . -20)
          (class . title)
          (text . window-name)
          (x-justify . 10)
          (y-justify . 5)
          (foreground . "#e6c8e6c8e6c8"))
         ((height . 20)
          (top-edge . -20)
          (background . "grabby")
          (left-edge . 6)
          (class . menu-button))
         ((class . title)
          (right-edge . 0)
          (top-edge . -20)
          (background . "topright"))
         ((class . title)
          (left-edge . 0)
          (top-edge . -20)
          (background . "topleft"))
         ((top-edge . -2)
          (left-edge . 0)
          (right-edge . 0)
          (background . "bottom-shade")
          (class . bottom-border)))
        ("unframed")))

     (mapping-alist
      '((default . "normal")
        (transient . "transient")
        (shaped . "shaped")
        (shaped-transient . "shaped-transient")
        (unframed . "none")))

     (theme-name 'LiquidGnome))

  (add-frame-style
   theme-name (make-theme patterns-alist frames-alist mapping-alist))
  (when (boundp 'mark-frame-style-editable)
    (mark-frame-style-editable theme-name)))
